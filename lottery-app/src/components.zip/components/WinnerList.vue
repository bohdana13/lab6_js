<!-- WinnerList.vue -->
<template>
  <div class="card">
    <div class="d-flex">
      <div class="winner-tags gray-border">
        <Winner
          v-for="(winner, index) in winners"
          :key="index"
          :winner="winner"
          :removeWinner="() => removeWinner(index)"
        />
        <span class="badge">Winners</span>
      </div>
    </div>
    <button
      class="btn btn-primary mt-2"
      :disabled="winners.length >= 3 || participants.length === 0"
      @click="selectWinner"
    >
      New Winner
    </button>
  </div>
</template>

<script lang="ts">
import { defineComponent, PropType } from "vue";
import { Participant } from "../models/Participant";
import Winner from "./WinnerComponent.vue";

export default defineComponent({
  name: "WinnerListBlock",
  components: {
    Winner,
  },
  props: {
    winners: {
      type: Array as PropType<Participant[]>,
      required: true,
    },
    participants: {
      type: Array as PropType<Participant[]>,
      required: true,
    },
    selectWinner: {
      type: Function as PropType<() => void>,
      required: true,
    },
    removeWinner: {
      type: Function as PropType<(index: number) => void>,
      required: true,
    },
  },
  setup(props) {
    const removeWinner = (index: number) => {
      props.removeWinner(index); // Pass the index to the parent method
    };

    return {
      // eslint-disable-next-line vue/no-dupe-keys
      removeWinner,
    };
  },
});
</script>

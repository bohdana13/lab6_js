<template>
  <div class="winner-tags gray-border">
    <Winner
      v-for="(winner, index) in winners"
      :key="index"
      :winner="winner"
      :removeWinner="() => removeWinner(index)"
    />
    <span class="badge">Winners</span>
  </div>
</template>

<script lang="ts">
import Winner from "./WinnerComponent.vue";

export default {
  name: "WinnerList",
  components: {
    Winner,
  },
  props: {
    winners: Array,
    removeWinner: Function,
  },
};
</script>

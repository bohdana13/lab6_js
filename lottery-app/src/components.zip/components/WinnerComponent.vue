<!-- WinnerComponent.vue -->
<template>
  <span class="badge blue" v-if="winner">
    {{ winner.name }}
    <!-- Trigger removeWinner when button is clicked -->
    <button @click="removeWinner" class="btn btn-sm btn-danger">&times;</button>
  </span>
</template>

<script lang="ts">
import { defineComponent, PropType } from "vue";
import { Participant } from "../models/Participant";

export default defineComponent({
  name: "WinnerComponent",
  props: {
    winner: {
      type: Object as PropType<Participant>, // Define the type of the 'winner' prop
      required: true,
    },
    removeWinner: {
      type: Function as PropType<() => void>, // Define the type of the 'removeWinner' prop
      required: true,
    },
  },
  setup(props) {
    // Now TypeScript knows that `props` has a specific type
    const removeWinner = () => {
      // Call the parent's removeWinner method when the button is clicked
      props.removeWinner();
    };

    return {
      // eslint-disable-next-line vue/no-dupe-keys
      removeWinner,
    };
  },
});
</script>

<template>
  <div>
    <div>
      <button
        :disabled="winners.length === 3 || participants.length === 0"
        @click="pickNewWinner"
      >
        New Winner
      </button>
    </div>

    <div v-if="winners.length > 0">
      <h3>Winners:</h3>
      <ul>
        <li v-for="(winner, index) in winners" :key="index">
          {{ winner.name }}
          <button @click="removeWinner(index)">Remove</button>
        </li>
      </ul>
    </div>

    <div v-else>
      <p>No winners yet.</p>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from "vue";

export interface Participant {
  name: string;
  dateOfBirth: string;
  email: string;
  phoneNumber: string;
}

export default defineComponent({
  name: "WinnerComponent",
  setup() {
    const participants = ref<Participant[]>([
      {
        name: "John Doe",
        dateOfBirth: "1990-01-01",
        email: "john@example.com",
        phoneNumber: "1234567890",
      },
      {
        name: "Jane Smith",
        dateOfBirth: "1985-05-05",
        email: "jane@example.com",
        phoneNumber: "9876543210",
      },
      {
        name: "Alice Johnson",
        dateOfBirth: "1992-09-15",
        email: "alice@example.com",
        phoneNumber: "5551234567",
      },
      {
        name: "Bob Brown",
        dateOfBirth: "1990-03-25",
        email: "bob@example.com",
        phoneNumber: "5559876543",
      },
    ]);

    const winners = ref<Participant[]>([]);

    const pickNewWinner = () => {
      if (winners.value.length < 3 && participants.value.length > 0) {
        const randomIndex = Math.floor(
          Math.random() * participants.value.length
        );
        const newWinner = participants.value[randomIndex];

        // Ensure no duplicate winners
        if (!winners.value.some((winner) => winner.name === newWinner.name)) {
          winners.value.push(newWinner);
        }
      }
    };

    const removeWinner = (index: number) => {
      winners.value.splice(index, 1);
    };

    return {
      participants,
      winners,
      pickNewWinner,
      removeWinner,
    };
  },
});
</script>

<style scoped>
button {
  margin-left: 10px;
}
</style>
